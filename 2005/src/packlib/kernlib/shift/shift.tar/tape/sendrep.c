/*
 * Copyright (C) 1990-1997 by CERN/CN/SW/CU
 * All rights reserved
 */

#ifndef lint
static char sccsid[] = "@(#)sendrep.c	1.9 05/07/97 CERN CN-SW/CU Jean-Philippe Baud";
#endif /* not lint */

#include <errno.h>
#include <fcntl.h>
#include "tape.h"
sendrep(rpn, repp)
char *rpn;
struct tpdrep *repp;
{
	char func[16];
	int rpfd;

	ENTRY (sendrep);
#if ultrix || hpux || apollo || _AIX || (__alpha && __osf__) || SOLARIS || IRIX5 || linux
	rpfd = atoi (rpn);
#else
	if ((rpfd = open (rpn, O_WRONLY | O_NDELAY)) < 0) {
		tplogit (func, TP002, rpn, "open", errno);
		if (errno == ENXIO) unlink (rpn);
		RETURN (-1);
	}
#endif
	if (WRITE (rpfd, (char *) repp, repp->rh.size) != repp->rh.size) {
		tplogit (func, TP002, rpn, "write", errno);
		close (rpfd);
		RETURN (-1);
	}
	close (rpfd);
	RETURN (0);
}
