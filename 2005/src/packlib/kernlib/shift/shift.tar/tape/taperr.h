/*
 * Copyright (C) 1994-1995 by CERN/CN/PDP/DH
 * All rights reserved
 */

/*
 * @(#)taperr.h	1.2 06/06/95 CERN CN-PDP/DH Jean-Philippe Baud
 */

#define ETBLANK	216	/* blank tape */
#define ETCOMPA	217	/* compatibility problem */
#define ETHWERR	218	/* device malfunction */
#define ETPARIT	219	/* parity error */
#define ETUNREC	220	/* unrecoverable media error */
#define ETNOSNS	221	/* no sense */
