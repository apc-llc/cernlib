/*
 * Copyright (C) 1990-1994 by CERN/CN/SW/CU
 * All rights reserved
 */

#ifndef lint
static char sccsid[] = "@(#)buildvollbl.c	1.3 05/17/94 CERN CN-SW/CU Jean-Philippe Baud";
#endif /* not lint */

/*	buildvollbl - build VOL1 */
#include <sys/types.h>
#include "tape.h"
buildvollbl(vol1, vsn, lbl, name)
char vol1[];
char *vsn;
int lbl;
char *name;
{
	int i;

	/* build VOL1 */

	for (i = 0; i < 80; i++)
		vol1[i] = ' ';
	vol1[80] = '\0';
	strcpy (vol1, "VOL1");
	memcpy (vol1 + 4, vsn, strlen(vsn));
	if (lbl == SL)
		memcpy (vol1 + 41, name, strlen(name));
	if (lbl == AL)
		vol1[79] = '3';
}
