/*
 * Copyright (C) 1995 by CERN CN-PDP/CS
 * All rights reserved
 */

/*
 * @(#)getacct.h	1.1 06/14/95 CERN CN-PDP/CS Antony Simmins
 */


#ifndef GETACCT_H
#define GETACCT_H

#define ACCOUNT_VAR	"ACCOUNT"

#define EMPTY_STR	""
#define COLON_STR	":"

#endif /* GETACCT_H */
