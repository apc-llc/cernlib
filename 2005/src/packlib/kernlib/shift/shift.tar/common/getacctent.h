/*
 * Copyright (C) 1995-1997 by CERN CN-PDP/CS
 * All rights reserved
 */

/*
 * @(#)getacctent.h	1.3 09/09/97 CERN CN-PDP/CS Antony Simmins
 */


#ifndef GETACCTENT_H
#define GETACCTENT_H
#ifndef ACCT_FILE
#if defined(_WIN32)
#define ACCT_FILE "%SystemRoot%\\system32\\drivers\\etc\\account"
#else
#define ACCT_FILE	"/etc/account"
#endif
#endif
#define ACCT_FILE_VAR	"ACCT_FILE"

#define DFLT_SEQ_NUM	0

#define NEWLINE	'\n'
#define ENDSTR	'\0'

#define PLUS_STR	"+"
#define COLON_STR	":"

#endif /* GETACCTENT_H */
