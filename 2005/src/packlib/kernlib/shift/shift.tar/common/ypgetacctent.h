/*
 * Copyright (C) 1995 by CERN CN-PDP/CS
 * All rights reserved
 */

/*
 * @(#)ypgetacctent.h	1.1 06/14/95 CERN CN-PDP/CS Antony Simmins
 */


#ifndef YPGETACCTENT_H
#define YPGETACCTENT_H

#define ACCT_MAP_NAME	"account"

#define DFLT_SEQ_STR	"0"
#define MAX_SEQ_NUM	8

#define NAME_LEN	10
#define ACCT_LEN	9

#define FALSE		0
#define TRUE		1

#define NEWLINE_CHR	'\n'
#define ENDSTR_CHR	'\0'
#define STAR_CHR	'*'

#define STAR_STR	"*"
#define COLON_STR	":"

#endif /* YPGETACCTENT_H */
