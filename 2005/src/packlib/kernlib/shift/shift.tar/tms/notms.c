/*
 * Copyright (C) 1990-1996 by CERN/CN/SW/CU
 * All rights reserved
 */

#ifndef lint
static char sccsid[] = "@(#)notms.c	1.3 01/25/96 CERN CN-SW/CU Jean-Philippe Baud";
#endif /* not lint */

/*	Tell tmsdaemon that TMS server is not active for a long period of time */

#include <sys/types.h>
#include <fcntl.h>
#include <time.h>
#include "tms.h"
char *ctime();

main()
{
	char func[16];
	time_t current_time;
	int fd;

	strcpy (func, "notms");
	time (&current_time);
	fd = open (NOTMS, O_WRONLY | O_CREAT, 0664);
	write (fd, ctime (&current_time), 26); 
	close (fd);
	tmslogit (func, TMS17);
}
