/*
 * Copyright (C) 1990,1991,1992 by CERN/CN/SW/CU
 * All rights reserved
 */

#ifndef lint
static char sccsid[] = "@(#)tmsactive.c	1.4 12/09/92 CERN CN-SW/CU Jean-Philippe Baud";
#endif /* not lint */

/*	Tell tmsdaemon that TMS on VM should be currently active */

#include <stdio.h>
#include <sys/param.h>
#include <sys/types.h>
#include "tms.h"
static char teststring[]="HOSTCMD CP MESSAGE CONSOLE TMS TEST FROM ";

main()
{
	int c;
	char func[16];
	char hostname[MAXHOSTNAMELEN];
	int repsize;
	char reqbuf[128];
	char tmrepbuf[TMREPBUFSZ];

	strcpy (func, "tmsactive");
	gethostname (hostname, MAXHOSTNAMELEN);
	sprintf (reqbuf, "%s%s(%s)", teststring, SYSTEM, hostname);
	repsize = TMREPBUFSZ;
	c = _sysreq ("root", "xmp$cy", "TMS", reqbuf, strlen(reqbuf),
		tmrepbuf, &repsize);
	if (c == 0) {
		unlink (NOTMS);
		tmslogit (func, TMS18);
	} else if (c < 0) {
		perror ("tmsactive");
	} else {
		fprintf (stderr, "%s\n", tmrepbuf);
	}
}
