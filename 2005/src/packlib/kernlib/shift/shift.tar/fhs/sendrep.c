/*
 * Copyright (C) 1992 by CERN/CN/SW/CU
 * All rights reserved
 */

#ifndef lint
static char sccsid[] = "@(#)sendrep.c	1.1 02/19/93 CERN CN-SW/CU Jean-Philippe Baud";
#endif /* not lint */

#include <errno.h>
#include <sys/types.h>
#include <fcntl.h>
#include "fhs.h"
sendrep(rpn, repp)
char *rpn;
struct fhdrep *repp;
{
	char func[16];
	int rpfd;

	strcpy (func, "sendrep");
#if _AIX
	rpfd = atoi (rpn);
#else
	if ((rpfd = open (rpn, O_WRONLY | O_NDELAY)) < 0) {
		fhslogit (func, FHS01, rpn, "open", errno);
		if (errno == ENXIO) unlink (rpn);
		return (-1);
	}
#endif
	if (WRITE (rpfd, (char *) repp, repp->rh.size) != repp->rh.size) {
		fhslogit (func, FHS01, rpn, "write", errno);
		close (rpfd);
		return (-1);
	}
	close (rpfd);
	return (0);
}
