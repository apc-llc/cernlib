/*
 * Copyright (C) 1993 by CERN/CN/SW/CU
 * All rights reserved
 */

#ifndef lint
static char sccsid[] = "@(#)fhsactive.c	1.1 02/19/93 CERN CN-SW/CU Jean-Philippe Baud";
#endif /* not lint */

/*	Tell fhsdaemon that FHS on VM should be currently active */

#include <stdio.h>
#include <sys/types.h>
#include "fhs.h"

main()
{
	char func[16];

	strcpy (func, "fhsactive");
	unlink (NOFHS);
	fhslogit (func, FHS18);
}
