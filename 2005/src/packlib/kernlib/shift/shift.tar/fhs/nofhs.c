/*
 * Copyright (C) 1993 by CERN/CN/SW/CU
 * All rights reserved
 */

#ifndef lint
static char sccsid[] = "@(#)nofhs.c	1.1 02/19/93 CERN CN-SW/CU Jean-Philippe Baud";
#endif /* not lint */

/*	Tell fhsdaemon that FHS on VM is not active for a long period of time */

#include <sys/types.h>
#include <fcntl.h>
#include <time.h>
#include "fhs.h"
char *ctime();

main()
{
	char func[16];
	time_t current_time;
	int fd;

	strcpy (func, "nofhs");
	time (&current_time);
	fd = open (NOFHS, O_WRONLY | O_CREAT, 0664);
	write (fd, ctime (&current_time), 26); 
	close (fd);
	fhslogit (func, FHS17);
}
