/*
 * Copyright (C) 1990,1991 by CERN/CN/SW/DC
 * All rights reserved
 */

#ifndef lint
static char sccsid[] =
"@(#)chk80.c	1.1 08/26/91 CERN CN-SW/DC Frederic Hemmer";
#endif /* not lint */

/* chk80.c      check a file line length limit                  */

#include <stdio.h>

main(argc, argv)
int     argc;
char    **argv;
{
	int     lineno;
	char    buf[BUFSIZ];
	FILE    *fp;

	while (argc-- > 1)      {
		if ((fp = fopen(argv[argc],"r")) == NULL)       {
			perror(argv[argc]);
			exit(1);
		}
		lineno = 0;
		while (fgets(buf, BUFSIZ, fp) != NULL)  {
			lineno++;
			if (strlen(buf) >= 80)  {
				fprintf(stdout,"%s: line %d is %d long\n",
					argv[argc], lineno, strlen(buf));
			}
		}
	}
}
