/*
 * Copyright (C) 1990,1991 by CERN/CN/SW/DC
 * All rights reserved
 */

#ifndef lint
static char sccsid[] = "@(#)tptime.c	2.1 07/17/91 CERN CN-SW/DC Antoine Trannoy";
#endif /* not lint */

/* tptime.c             return time in seconds.          */

#include <stdio.h>
#include <sys/types.h>

main()
{
	extern time_t time() ; 
	time_t 	       clock ; 

	(void) time(&clock) ; 
	(void) printf("%d",clock) ; 
}

