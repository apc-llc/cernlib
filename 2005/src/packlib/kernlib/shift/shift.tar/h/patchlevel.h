/*
 * @(#)patchlevel.h	1.5 06/21/94 CERN CN-SW/DC F. Hemmer
 */

/*
 * Copyright (C) 1990-1994 by CERN CN-PDP/CS
 * All rights reserved
 */

/* patchlevel.h                 Patch level                             */

#ifndef _PATCHLEVEL_H_INCLUDED_
#define _PATCHLEVEL_H_INCLUDED_

#define BASEVERSION     "1.10.3"
#define PATCHLEVEL      5
#define TIMESTAMP       "991111154401"

#endif /* _PATCHLEVEL_H_INCLUDED_ */
