/*
 * Copyright (C) 1994 CERN/CN/PDP/CS
 * All rights reserved
 */

#ifndef lint
static char sccsid[] = "@(#)chkserv.c	1.2 04/22/94 CERN CN-SW/DC F. Hassine ";
#endif /* not lint */

/* chkserv.c    Remote File I/O - check availability of daemon  */

#define RFIO_KERNEL     1
#include <rfio.h>

int rfio_chkserv (host)
char *host ;
{
	int rcode , rt;
	char *p ;

        rcode=RFIO_NONET ;
        rfiosetopt(RFIO_NETOPT, &rcode , 4);

	rcode = rfio_connect (host,&rt);
        if (rcode <0 ) 
		return rcode ;

	p = rfio_buf ;
        marshall_WORD(p, RFIO_MAGIC );
        marshall_WORD(p, RQST_CHKCON ) ;
	
	if (netwrite(rcode, rfio_buf, RQSTSIZE )!=  RQSTSIZE ) {
		INIT_TRACE("RFIO_TRACE");
		TRACE(2,"rfio","rfio_chkserv() : write() : ERROR occured (errno=%d)", errno) ;
		END_TRACE() ;
		return -1 ;
	}
	if ( netread( rcode , rfio_buf, LONGSIZE) != LONGSIZE ) {
		INIT_TRACE("RFIO_TRACE");
		TRACE(2,"rfio","rfio_chkserv() : read() : ERROR occured (errno=%d)", errno) ;
		END_TRACE() ;
                return -1 ;
        }

	(void) close(rcode) ;
	return 0 ;
}



